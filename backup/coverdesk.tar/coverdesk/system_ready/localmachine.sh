#!/bin/sh

#Basic Required Software post ubuntu installation is completed 
    # vscode 
    # chrome
    # vim
    # git 
    # Java
    # Virtual Box
    # Anaconda
    # Apache


# VSCode , Chrome , Virtual Box -- Download .deb files from online and install using 
# sudo apt install ./<package_name>.deb

sudo apt install git vim -y 